<link rel="stylesheet" type="text/css" href="/css/cart.css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="contentcart">

	<h1>Keranjang Peminjaman</h1>

	<div class="cart">

		<div class="products">

			<div class="product">

				<img src="/img/img.jpg">

				<div class="product-info">

					<h3 class="product-name">Naruto Shippuden</h3>

					<h4 class="product-price">Tanggal Pinjam <input type="date" id="tglpinjam" name="tglpinjam"></h4>

					<h4 class="product-offer">Tanggal Kembali <input type="date" id="tglkembali" name="tglkembali"></h4>

					<p class="product-quantity">Qnt: <input value="1" name="">

					<p class="product-remove">

						<i class="fa fa-trash" aria-hidden="true"></i>

						<span class="remove">Remove</span>

					</p>

				</div>

			</div>
			<div class="product">

				<img src="/img/img.jpg">

				<div class="product-info">

					<h3 class="product-name">Naruto Shippuden</h3>

					<h4 class="product-price">Tanggal Pinjam <input type="date" id="tglpinjam" name="tglpinjam"></h4>

					<h4 class="product-offer">Tanggal Kembali <input type="date" id="tglkembali" name="tglkembali"></h4>

					<p class="product-quantity">Qnt: <input value="1" name="">

					<p class="product-remove">

						<i class="fa fa-trash" aria-hidden="true"></i>

						<span class="remove">Remove</span>

					</p>

				</div>

			</div>
			<div class="product">

				<img src="/img/img.jpg">

				<div class="product-info">

					<h3 class="product-name">Naruto Shippuden</h3>

					<h4 class="product-price">Tanggal Pinjam <input type="date" id="tglpinjam" name="tglpinjam"></h4>

					<h4 class="product-offer">Tanggal Kembali <input type="date" id="tglkembali" name="tglkembali"></h4>

					<p class="product-quantity">Qnt: <input value="1" name="">

					<p class="product-remove">

						<i class="fa fa-trash" aria-hidden="true"></i>

						<span class="remove">Remove</span>

					</p>

				</div>

			</div>
			<div class="product">

				<img src="/img/img.jpg">

				<div class="product-info">

					<h3 class="product-name">Naruto Shippuden</h3>

					<h4 class="product-price">Tanggal Pinjam <input type="date" id="tglpinjam" name="tglpinjam"></h4>

					<h4 class="product-offer">Tanggal Kembali <input type="date" id="tglkembali" name="tglkembali"></h4>

					<p class="product-quantity">Qnt: <input value="1" name="">

					<p class="product-remove">

						<i class="fa fa-trash" aria-hidden="true"></i>

						<span class="remove">Remove</span>

					</p>

				</div>

			</div>
			<div class="product">

				<img src="/img/img.jpg">

				<div class="product-info">

					<h3 class="product-name">Naruto Shippuden</h3>

					<h4 class="product-price">Tanggal Pinjam <input type="date" id="tglpinjam" name="tglpinjam"></h4>

					<h4 class="product-offer">Tanggal Kembali <input type="date" id="tglkembali" name="tglkembali"></h4>

					<p class="product-quantity">Qnt: <input value="1" name="">

					<p class="product-remove">

						<i class="fa fa-trash" aria-hidden="true"></i>

						<span class="remove">Remove</span>

					</p>

				</div>

			</div>
			<div class="product">

				<img src="/img/img.jpg">

				<div class="product-info">

					<h3 class="product-name">Naruto Shippuden</h3>

					<h4 class="product-price">Tanggal Pinjam <input type="date" id="tglpinjam" name="tglpinjam"></h4>

					<h4 class="product-offer">Tanggal Kembali <input type="date" id="tglkembali" name="tglkembali"></h4>

					<p class="product-quantity">Qnt: <input value="1" name="">

					<p class="product-remove">

						<i class="fa fa-trash" aria-hidden="true"></i>

						<span class="remove">Remove</span>

					</p>

				</div>

			</div>
			<div class="product">

				<img src="/img/img.jpg">

				<div class="product-info">

					<h3 class="product-name">Naruto Shippuden</h3>

					<h4 class="product-price">Tanggal Pinjam <input type="date" id="tglpinjam" name="tglpinjam"></h4>

					<h4 class="product-offer">Tanggal Kembali <input type="date" id="tglkembali" name="tglkembali"></h4>

					<p class="product-quantity">Qnt: <input value="1" name="">

					<p class="product-remove">

						<i class="fa fa-trash" aria-hidden="true"></i>

						<span class="remove">Remove</span>

					</p>

				</div>

			</div>

			

		</div>

		<div class="cart-total">


			<p>

				<span>Total Buku</span>

				<span>1</span>

			</p>


			<a href="#">Ajukan Peminjaman</a>

		</div>

	</div>

</div>