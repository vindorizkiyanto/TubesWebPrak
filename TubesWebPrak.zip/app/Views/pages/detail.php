<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />

<link rel="stylesheet" href="/css/style.css">
<div class="detail">
    <div class="cover"><img src="/img/img.jpg" alt=""></div>
    <div class="content">
        <div class="nav">
            <span class="logo">Masashi Kishimoto</span>
        </div>
        <div class="content-body">
            <div class="pages">
                <span class="active"><b>012212</b></span>
            </div>
            <div class="black-label">
                <span class="title"><b>Naruto Shippuden Volume 41</b></span>
                <p>Naruto Shippuden adalah sebuah seri anime yang diadaptasi dari bagian II manga Naruto. Serial ini disutradarai oleh Hayato Date dan diproduksi oleh Studio Pierrot dan TV Tokyo. Pada bagian ini, pergerakan organisasi Akatsuki semakin terlihat.
                </p>

                <div class="prix">
                    <span><b>Stok : 10</b></span>
                    <a href="" class=""><span class="crt" >Add to card</span></a>
                    <a href="" class=""><span class="crt">Back to Home</span></a>
                </div>
            </div>


        </div>

    </div>
</div>